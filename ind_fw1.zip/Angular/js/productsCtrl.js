app.controller('productsCtrl', function($scope) {
    $scope.services = [
        { "title": "Antalya", "time": "7 days", "climate": "hot", "price": 200, "image": "images/antalya.jpg" },
        { "title": "Dublin", "time": "5 days", "climate": "moder. warm", "price": 350, "image": "images/dublin.jpg" },
        { "title": "Frankfurt", "time": "5 days", "climate": "moder. warm", "price": 200, "image": "images/frankfurt.jpg" },
        { "title": "Moscow", "time": "10 days", "climate": "cold", "price": 300, "image": "images/moskow.jpg" },
        { "title": "Istambul", "time": "4 days", "climate": "moder. warm", "price": 150, "image": "images/stambul.jpg" },
        { "title": "Tel Aviv", "time": "7 days", "climate": "warm", "price": 450, "image": "images/tel-aviv.jpg" },
        { "title": "Verona", "time": "5 days", "climate": "humid", "price": 250, "image": "images/verona.jpg" },
        { "title": "Roma", "time": "5 days",  "climate": "moder. warm", "price": 300, "image": "images/roma.jpg" },
        { "title": "London", "time": "10 days", "climate": "humid", "price": 800, "image": "images/london.jpg" },
          ];

    $scope.inputLogin = "";
    $scope.inputPass = "";

    $scope.login = "admin";
    $scope.password = "password";
    $scope.isSignIn = false;
    $scope.editing = false;


    $scope.signIn = function() {
        if ($scope.inputLogin === $scope.login) {
            if ($scope.inputPass == $scope.password) {
                $scope.isSignIn = true;
                document.getElementById('myModal').style.display = "none"
            }
        }
    };

    $scope.removeProduct = function(itemTitle) {
        const index = $scope.services.findIndex(x => x.title === itemTitle);

        $scope.services.splice(index, 1);

        console.log(index);
    }
	


    $scope.addNewService = function() {
        newService = {
            title: "Unknown",
            price: 0,
            image: "images/logo.png"
        }

        $scope.services.push(newService);
    }


    $scope.orderByMe = function(item) {
        $scope.myOrderBy = item;
        $scope.reverseOrder();
    }

    $scope.myReverseBy = false;
    $scope.reverseOrder = function() {
        $scope.myReverseBy = !($scope.myReverseBy);
    }


});